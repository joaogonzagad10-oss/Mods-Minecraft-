# QoL Miner Mod (Minecraft Java 1.18.2 - Forge)

Mod de Qualidade de Vida para Minecraft 1.18.2 (Forge) com 3 funcionalidades principais:

1. **Capacete de Minerador com Lanterna (`qolmod:miner_helmet`):**
   - Ilumina automaticamente ao redor do jogador enquanto equipado na cabeça, deixando a mão secundária livre para Escudo ou Totem da Imortalidade.
   - Craftável com barras de ferro, barra de ouro e uma lanterna.
2. **Colheita Rápida:**
   - Clique com o **botão direito** em qualquer plantação madura (trigo, cenoura, batata, beterraba, etc.) para colher e replantar automaticamente.
3. **Túmulo de Morte (Gravestone):**
   - Ao morrer, cria um bloco de lápide no local que guarda todo o seu inventário, armadura e mão secundária com segurança até você clicar com o botão direito ou quebrar o bloco para recuperar tudo.

## Como compilar o `.jar`
- **No PC (com Gradle/IntelliJ):** rode `./gradlew build` (ou `gradle build`). O arquivo `.jar` será gerado em `build/libs/`.
- **Pelo GitHub:** basta subir este repositório para o GitHub — já incluímos uma GitHub Action (`.github/workflows/build.yml`) que compila o `.jar` automaticamente na aba **Actions**!
