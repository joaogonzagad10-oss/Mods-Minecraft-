package com.seunome.qolmod;

import com.seunome.qolmod.block.ModBlocks;
import com.seunome.qolmod.block.entity.ModBlockEntities;
import com.seunome.qolmod.item.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(QoLMod.MOD_ID)
public class QoLMod {
    public static final String MOD_ID = "qolmod";

    public QoLMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
    }
}
