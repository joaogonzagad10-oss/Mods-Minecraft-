package com.seunome.qolmod.block.entity;

import com.seunome.qolmod.QoLMod;
import com.seunome.qolmod.block.ModBlocks;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITIES, QoLMod.MOD_ID);

    public static final RegistryObject<BlockEntityType<GravestoneBlockEntity>> GRAVESTONE =
            BLOCK_ENTITIES.register("gravestone",
                    () -> BlockEntityType.Builder.of(GravestoneBlockEntity::new, ModBlocks.GRAVESTONE.get()).build(null));
}
