package com.seunome.qolmod.block;

import com.seunome.qolmod.QoLMod;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Material;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, QoLMod.MOD_ID);

    public static final RegistryObject<Block> GRAVESTONE = BLOCKS.register("gravestone",
            () -> new GravestoneBlock(BlockBehaviour.Properties.of(Material.STONE)
                    .strength(2.5F, 1200.0F)
                    .sound(SoundType.STONE)
                    .noOcclusion()));
}
