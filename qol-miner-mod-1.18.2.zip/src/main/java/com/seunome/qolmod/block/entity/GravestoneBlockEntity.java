package com.seunome.qolmod.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

public class GravestoneBlockEntity extends BlockEntity {
    private NonNullList<ItemStack> items = NonNullList.withSize(54, ItemStack.EMPTY);
    private String ownerName = "";

    public GravestoneBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GRAVESTONE.get(), pos, state);
    }

    public void setStoredItems(List<ItemStack> drops, String ownerName) {
        this.ownerName = ownerName;
        this.items = NonNullList.withSize(Math.max(54, drops.size()), ItemStack.EMPTY);
        for (int i = 0; i < drops.size(); i++) {
            this.items.set(i, drops.get(i).copy());
        }
        setChanged();
    }

    public NonNullList<ItemStack> getItems() {
        return this.items;
    }

    public String getOwnerName() {
        return this.ownerName;
    }

    public void restoreToPlayer(Player player) {
        for (int i = 0; i < items.size(); i++) {
            ItemStack stack = items.get(i);
            if (!stack.isEmpty()) {
                if (!player.getInventory().add(stack)) {
                    player.drop(stack, false);
                }
                items.set(i, ItemStack.EMPTY);
            }
        }
        setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, this.items);
        tag.putString("OwnerName", this.ownerName);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.items = NonNullList.withSize(54, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, this.items);
        this.ownerName = tag.getString("OwnerName");
    }
}
