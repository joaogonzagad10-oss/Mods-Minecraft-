package com.seunome.qolmod.item;

import com.seunome.qolmod.QoLMod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = QoLMod.MOD_ID)
public class MinerHelmetItem extends ArmorItem {
    private static final Map<UUID, BlockPos> LAST_LIGHT_POS = new HashMap<>();

    public MinerHelmetItem(ArmorMaterial material, EquipmentSlot slot, Properties properties) {
        super(material, slot, properties);
    }

    @Override
    public void onArmorTick(ItemStack stack, Level level, Player player) {
        if (level.isClientSide()) return;

        UUID playerId = player.getUUID();
        BlockPos targetPos = player.blockPosition().above();
        if (!level.getBlockState(targetPos).isAir() && !level.getBlockState(targetPos).is(Blocks.LIGHT)) {
            targetPos = player.blockPosition();
        }

        BlockPos previousPos = LAST_LIGHT_POS.get(playerId);
        if (previousPos != null && !previousPos.equals(targetPos)) {
            if (level.getBlockState(previousPos).is(Blocks.LIGHT)) {
                level.setBlock(previousPos, Blocks.AIR.defaultBlockState(), 3);
            }
        }

        BlockState currentState = level.getBlockState(targetPos);
        if (currentState.isAir() || currentState.is(Blocks.LIGHT)) {
            BlockState lightState = Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, 14);
            level.setBlock(targetPos, lightState, 3);
            LAST_LIGHT_POS.put(playerId, targetPos);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level.isClientSide()) return;

        Player player = event.player;
        ItemStack headItem = player.getItemBySlot(EquipmentSlot.HEAD);
        if (!(headItem.getItem() instanceof MinerHelmetItem)) {
            removeLightFor(player);
        }
    }

    @SubscribeEvent
    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        removeLightFor(event.getPlayer());
    }

    private static void removeLightFor(Player player) {
        BlockPos previousPos = LAST_LIGHT_POS.remove(player.getUUID());
        if (previousPos != null && player.level.getBlockState(previousPos).is(Blocks.LIGHT)) {
            player.level.setBlock(previousPos, Blocks.AIR.defaultBlockState(), 3);
        }
    }
}
