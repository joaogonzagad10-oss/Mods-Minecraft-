package com.seunome.qolmod.events;

import com.seunome.qolmod.QoLMod;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = QoLMod.MOD_ID)
public class QuickHarvestEvents {

    @SubscribeEvent
    public static void onRightClickCrop(PlayerInteractEvent.RightClickBlock event) {
        Level level = event.getWorld();
        if (level.isClientSide() || event.getHand() != InteractionHand.MAIN_HAND) return;

        BlockPos pos = event.getPos();
        BlockState state = level.getBlockState(pos);
        Block block = state.getBlock();

        if (block instanceof CropBlock crop && crop.isMaxAge(state)) {
            Player player = event.getPlayer();
            ServerLevel serverLevel = (ServerLevel) level;

            List<ItemStack> drops = Block.getDrops(state, serverLevel, pos, null, player, player.getMainHandItem());

            boolean replanted = false;
            ItemStack seedItem = crop.getCloneItemStack(level, pos, state);
            for (ItemStack drop : drops) {
                if (!replanted && drop.getItem() == seedItem.getItem()) {
                    drop.shrink(1);
                    replanted = true;
                }
                if (!drop.isEmpty()) {
                    Block.popResource(level, pos, drop);
                }
            }

            level.setBlock(pos, crop.getStateForAge(0), 3);
            level.playSound(null, pos, SoundEvents.CROP_PLANTED, SoundSource.BLOCKS, 1.0F, 1.0F);
            player.swing(InteractionHand.MAIN_HAND, true);
        }
    }
}
