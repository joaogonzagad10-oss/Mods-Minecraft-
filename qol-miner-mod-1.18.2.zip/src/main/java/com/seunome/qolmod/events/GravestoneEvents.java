package com.seunome.qolmod.events;

import com.seunome.qolmod.QoLMod;
import com.seunome.qolmod.block.GravestoneBlock;
import com.seunome.qolmod.block.ModBlocks;
import com.seunome.qolmod.block.entity.GravestoneBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = QoLMod.MOD_ID)
public class GravestoneEvents {

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onPlayerDrops(LivingDropsEvent event) {
        if (!(event.getEntityLiving() instanceof Player player)) return;

        Level level = player.level;
        if (level.isClientSide() || event.getDrops().isEmpty()) return;

        List<ItemStack> savedStacks = new ArrayList<>();
        for (ItemEntity itemEntity : event.getDrops()) {
            if (!itemEntity.getItem().isEmpty()) {
                savedStacks.add(itemEntity.getItem().copy());
            }
        }

        BlockPos gravePos = findSafeGravePos(level, player.blockPosition());
        BlockState graveState = ModBlocks.GRAVESTONE.get().defaultBlockState()
                .setValue(GravestoneBlock.FACING, player.getDirection().getOpposite());

        if (level.setBlock(gravePos, graveState, 3)) {
            BlockEntity be = level.getBlockEntity(gravePos);
            if (be instanceof GravestoneBlockEntity gravestone) {
                gravestone.setStoredItems(savedStacks, player.getName().getString());
                event.getDrops().clear();
                event.setCanceled(true);
                player.sendMessage(new TextComponent("§e[Túmulo] Seus itens foram guardados em: X="
                        + gravePos.getX() + " Y=" + gravePos.getY() + " Z=" + gravePos.getZ()), player.getUUID());
            }
        }
    }

    private static BlockPos findSafeGravePos(Level level, BlockPos origin) {
        int y = Math.max(level.getMinBuildHeight() + 1, Math.min(level.getMaxBuildHeight() - 2, origin.getY()));
        BlockPos clamped = new BlockPos(origin.getX(), y, origin.getZ());

        if (level.getBlockState(clamped).getMaterial().isReplaceable()) {
            return clamped;
        }
        for (int dy = 1; dy <= 5; dy++) {
            BlockPos above = clamped.above(dy);
            if (level.getBlockState(above).getMaterial().isReplaceable()) {
                return above;
            }
        }
        return clamped;
    }
}
