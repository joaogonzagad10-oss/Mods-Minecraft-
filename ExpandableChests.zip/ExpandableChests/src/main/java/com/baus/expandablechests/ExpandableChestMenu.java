package com.baus.expandablechests;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.SlotItemHandler;
import net.minecraftforge.items.wrapper.CombinedInvWrapper;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * Menu do baú gigante. Mostra até 6 linhas por vez; se houver mais slots,
 * usa páginas (botões < > ou roda do mouse).
 */
public class ExpandableChestMenu extends AbstractContainerMenu {
    public static final int MAX_ROWS = 6;

    private final IItemHandlerModifiable backing;
    private final List<ExpandableChestBlockEntity> chests; // só no servidor
    private final BlockPos pos;
    private final boolean server;
    private final int total;
    private final int rows;
    private final int perPage;
    private final int pages;
    private final DataSlot page = DataSlot.standalone();
    private final PageView view;

    // ---- construtor do servidor ----
    public ExpandableChestMenu(int id, Inventory inv, List<ExpandableChestBlockEntity> chests, BlockPos pos) {
        this(id, inv, combine(chests), chests, pos, chests.size() * ExpandableChestBlockEntity.SLOTS);
    }

    // ---- construtor do cliente ----
    public ExpandableChestMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, buf.readInt());
    }

    private ExpandableChestMenu(int id, Inventory inv, int total) {
        this(id, inv, new ItemStackHandler(perPageFor(total)), null, BlockPos.ZERO, total);
    }

    private ExpandableChestMenu(int id, Inventory inv, IItemHandlerModifiable backing,
                                List<ExpandableChestBlockEntity> chests, BlockPos pos, int total) {
        super(ModRegistry.EXPANDABLE_CHEST_MENU.get(), id);
        this.backing = backing;
        this.chests = chests;
        this.pos = pos;
        this.server = chests != null;
        this.total = total;
        this.rows = rowsFor(total);
        this.perPage = rows * 9;
        this.pages = Math.max(1, (total + perPage - 1) / perPage);
        this.view = new PageView();

        addDataSlot(page);

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < 9; c++) {
                addSlot(new PageSlot(view, r * 9 + c, 8 + c * 18, 18 + r * 18));
            }
        }

        int invY = 31 + rows * 18;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) {
                addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, invY + r * 18));
            }
        }
        for (int c = 0; c < 9; c++) {
            addSlot(new Slot(inv, c, 8 + c * 18, invY + 58));
        }
    }

    private static IItemHandlerModifiable combine(List<ExpandableChestBlockEntity> chests) {
        IItemHandlerModifiable[] arr = new IItemHandlerModifiable[chests.size()];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = chests.get(i).getItems();
        }
        return new CombinedInvWrapper(arr);
    }

    private static int rowsFor(int total) {
        return Math.min(MAX_ROWS, Math.max(1, (total + 8) / 9));
    }

    private static int perPageFor(int total) {
        return rowsFor(total) * 9;
    }

    public int getRows() {
        return rows;
    }

    public int getPage() {
        return page.get();
    }

    public int getPages() {
        return pages;
    }

    public int getTotal() {
        return total;
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (id == 0 && page.get() > 0) {
            page.set(page.get() - 1);
            return true;
        }
        if (id == 1 && page.get() < pages - 1) {
            page.set(page.get() + 1);
            return true;
        }
        return false;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();

        if (index < perPage) {
            // baú -> inventário do jogador
            if (!this.moveItemStackTo(stack, perPage, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else if (server) {
            // inventário -> qualquer lugar do baú gigante (todas as páginas)
            ItemStack remainder = ItemHandlerHelper.insertItem(backing, stack.copy(), false);
            if (remainder.getCount() == stack.getCount()) {
                return ItemStack.EMPTY;
            }
            stack.setCount(remainder.getCount());
        } else if (!this.moveItemStackTo(stack, 0, perPage, false)) {
            return ItemStack.EMPTY;
        }

        slot.set(stack.isEmpty() ? ItemStack.EMPTY : stack);
        return copy;
    }

    @Override
    public boolean stillValid(Player player) {
        if (!server) {
            return true;
        }
        for (ExpandableChestBlockEntity be : chests) {
            if (be.isRemoved()) {
                return false;
            }
        }
        return player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
    }

    /** Janela de {@code perPage} slots sobre o inventário combinado, deslocada pela página atual. */
    private class PageView implements IItemHandlerModifiable {
        boolean valid(int slot) {
            return slot >= 0 && slot < perPage && page.get() * perPage + slot < total;
        }

        int map(int slot) {
            return server ? page.get() * perPage + slot : slot;
        }

        @Override
        public int getSlots() {
            return perPage;
        }

        @Nonnull
        @Override
        public ItemStack getStackInSlot(int slot) {
            return valid(slot) ? backing.getStackInSlot(map(slot)) : ItemStack.EMPTY;
        }

        @Nonnull
        @Override
        public ItemStack insertItem(int slot, @Nonnull ItemStack stack, boolean simulate) {
            return valid(slot) ? backing.insertItem(map(slot), stack, simulate) : stack;
        }

        @Nonnull
        @Override
        public ItemStack extractItem(int slot, int amount, boolean simulate) {
            return valid(slot) ? backing.extractItem(map(slot), amount, simulate) : ItemStack.EMPTY;
        }

        @Override
        public int getSlotLimit(int slot) {
            return valid(slot) ? backing.getSlotLimit(map(slot)) : 64;
        }

        @Override
        public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
            return valid(slot) && backing.isItemValid(map(slot), stack);
        }

        @Override
        public void setStackInSlot(int slot, @Nonnull ItemStack stack) {
            if (valid(slot)) {
                backing.setStackInSlot(map(slot), stack);
            }
        }
    }

    /** Slot que some (fica inativo) quando está além do total na última página. */
    private class PageSlot extends SlotItemHandler {
        private final PageView pageView;
        private final int viewIndex;

        PageSlot(PageView pageView, int index, int x, int y) {
            super(pageView, index, x, y);
            this.pageView = pageView;
            this.viewIndex = index;
        }

        @Override
        public boolean isActive() {
            return pageView.valid(viewIndex);
        }
    }
}
