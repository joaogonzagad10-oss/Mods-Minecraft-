package com.baus.expandablechests;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Material;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    private ModRegistry() {}

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, ExpandableChestsMod.MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ExpandableChestsMod.MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITIES, ExpandableChestsMod.MODID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.CONTAINERS, ExpandableChestsMod.MODID);

    public static final RegistryObject<Block> EXPANDABLE_CHEST = BLOCKS.register("expandable_chest",
            () -> new ExpandableChestBlock(BlockBehaviour.Properties.of(Material.WOOD)
                    .strength(2.5F).sound(SoundType.WOOD)));

    public static final RegistryObject<Item> EXPANDABLE_CHEST_ITEM = ITEMS.register("expandable_chest",
            () -> new BlockItem(EXPANDABLE_CHEST.get(),
                    new Item.Properties().tab(CreativeModeTab.TAB_DECORATIONS)));

    public static final RegistryObject<BlockEntityType<ExpandableChestBlockEntity>> EXPANDABLE_CHEST_BE =
            BLOCK_ENTITIES.register("expandable_chest",
                    () -> BlockEntityType.Builder.of(ExpandableChestBlockEntity::new, EXPANDABLE_CHEST.get())
                            .build(null));

    public static final RegistryObject<MenuType<ExpandableChestMenu>> EXPANDABLE_CHEST_MENU =
            MENUS.register("expandable_chest", () -> IForgeMenuType.create(ExpandableChestMenu::new));
}
