package com.baus.expandablechests;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkHooks;

import javax.annotation.Nullable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ExpandableChestBlock extends BaseEntityBlock {
    /** Limite de baús juntos num único baú gigante. */
    public static final int MAX_CLUSTER = 1024;

    private static final Map<Direction, BooleanProperty> PROPS = new EnumMap<>(Direction.class);

    static {
        PROPS.put(Direction.NORTH, BlockStateProperties.NORTH);
        PROPS.put(Direction.SOUTH, BlockStateProperties.SOUTH);
        PROPS.put(Direction.EAST, BlockStateProperties.EAST);
        PROPS.put(Direction.WEST, BlockStateProperties.WEST);
        PROPS.put(Direction.UP, BlockStateProperties.UP);
        PROPS.put(Direction.DOWN, BlockStateProperties.DOWN);
    }

    public static BooleanProperty prop(Direction dir) {
        return PROPS.get(dir);
    }

    public ExpandableChestBlock(Properties properties) {
        super(properties);
        BlockState state = this.stateDefinition.any();
        for (Direction d : Direction.values()) {
            state = state.setValue(prop(d), false);
        }
        this.registerDefaultState(state);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        builder.add(BlockStateProperties.NORTH, BlockStateProperties.SOUTH, BlockStateProperties.EAST,
                BlockStateProperties.WEST, BlockStateProperties.UP, BlockStateProperties.DOWN);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState state = this.defaultBlockState();
        for (Direction d : Direction.values()) {
            BlockState neighbor = context.getLevel().getBlockState(context.getClickedPos().relative(d));
            state = state.setValue(prop(d), neighbor.is(this));
        }
        return state;
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighborState,
                                  LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        return state.setValue(prop(dir), neighborState.is(this));
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ExpandableChestBlockEntity(pos, state);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer serverPlayer) {
            List<ExpandableChestBlockEntity> cluster = collectCluster(level, pos);
            int total = cluster.size() * ExpandableChestBlockEntity.SLOTS;
            NetworkHooks.openGui(serverPlayer,
                    new SimpleMenuProvider(
                            (id, inv, p) -> new ExpandableChestMenu(id, inv, cluster, pos),
                            new TranslatableComponent("container.expandablechests.expandable_chest")),
                    buf -> buf.writeInt(total));
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock())) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof ExpandableChestBlockEntity chest) {
                chest.dropContents(level, pos);
            }
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    /** Encontra todos os baús conectados (nas 6 direções) ao baú em {@code start}. */
    public static List<ExpandableChestBlockEntity> collectCluster(Level level, BlockPos start) {
        Set<BlockPos> visited = new HashSet<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        List<ExpandableChestBlockEntity> result = new ArrayList<>();
        BlockPos first = start.immutable();
        visited.add(first);
        queue.add(first);
        while (!queue.isEmpty() && result.size() < MAX_CLUSTER) {
            BlockPos current = queue.poll();
            if (level.getBlockEntity(current) instanceof ExpandableChestBlockEntity be) {
                result.add(be);
            }
            for (Direction d : Direction.values()) {
                BlockPos next = current.relative(d);
                if (visited.contains(next) || !level.hasChunkAt(next)) {
                    continue;
                }
                if (level.getBlockState(next).getBlock() instanceof ExpandableChestBlock) {
                    visited.add(next);
                    queue.add(next);
                }
            }
        }
        result.sort(Comparator.comparing(ExpandableChestBlockEntity::getBlockPos));
        return result;
    }
}
